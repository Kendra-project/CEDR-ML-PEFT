#!/bin/bash

ARCH="x86"

if [ "$#" -eq 1 ]; then
  echo "Setting arch flag to $1"
  ARCH="$1"
fi

# ../../traceExtractCompile.sh \
#   --arch ${ARCH} --single-node \
#   -lm -lgsl -lgslcblas \
#   -d RF_convergence_support.c \
#   RF_convergence_LU_projection.c

#--loop-partition \
#--skip-trace \
#--skip-kernel-detection \
#../../traceExtractCompile.sh \
#  --arch ${ARCH} \
#  --inline \
#  --semantic-opt \
#  --skip-trace \
#  --skip-kernel-detection \
#  -lm -lgsl -lgslcblas \
#  -d RF_convergence_support.c \
#  RF_convergence_LU_projection.c

if [ "${ARCH}" == "x86" ]; then
  echo "Building for x86"
  ../../traceExtractCompile.sh \
    --arch x86 \
    --inline \
    --semantic-opt \
    -lm -lgsl -lgslcblas \
    --skip-trace \
    --skip-kernel-detection \
    -d RF_convergence_support.c \
    RF_convergence_LU_projection.c
else
  echo "Building for aarch64"
  ../../traceExtractCompile.sh \
    --arch aarch64 \
    --inline \
    --semantic-opt \
    -lm \
    --skip-trace \
    --skip-kernel-detection \
    -d RF_convergence_support.c \
    -od ../lib-aarch64/libgsl.a \
    -od ../lib-aarch64/libgslcblas.a \
    RF_convergence_LU_projection.c
fi
